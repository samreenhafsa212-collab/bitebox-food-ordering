CREATE DATABASE IF NOT EXISTS bitebox CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bitebox;

CREATE TABLE IF NOT EXISTS customers (
  customer_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(20),
  address VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS food_items (
  food_id INT UNSIGNED PRIMARY KEY,
  food_name VARCHAR(120) NOT NULL,
  category VARCHAR(60) NOT NULL,
  price_paise INT UNSIGNED NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS orders (
  order_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  customer_id BIGINT UNSIGNED NOT NULL,
  total_paise INT UNSIGNED NOT NULL,
  status ENUM('Pending','Confirmed','Preparing','Ready','Delivered','Cancelled') NOT NULL DEFAULT 'Pending',
  payment_status ENUM('Created','Paid','Failed','Refunded') NOT NULL DEFAULT 'Created',
  razorpay_order_id VARCHAR(100) UNIQUE,
  razorpay_payment_id VARCHAR(100) UNIQUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE IF NOT EXISTS order_details (
  order_id BIGINT UNSIGNED NOT NULL,
  food_id INT UNSIGNED NOT NULL,
  quantity INT UNSIGNED NOT NULL,
  unit_price_paise INT UNSIGNED NOT NULL,
  PRIMARY KEY (order_id, food_id),
  CONSTRAINT fk_details_order FOREIGN KEY (order_id) REFERENCES orders(order_id),
  CONSTRAINT fk_details_food FOREIGN KEY (food_id) REFERENCES food_items(food_id)
);

CREATE TABLE IF NOT EXISTS payments (
  payment_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id BIGINT UNSIGNED NOT NULL UNIQUE,
  amount_paise INT UNSIGNED NOT NULL,
  method VARCHAR(40) NOT NULL,
  status ENUM('Created','Paid','Failed','Refunded') NOT NULL DEFAULT 'Created',
  razorpay_order_id VARCHAR(100) NOT NULL,
  razorpay_payment_id VARCHAR(100) UNIQUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_payment_order FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

INSERT INTO food_items(food_id,food_name,category,price_paise) VALUES
(1,'Margherita Pizza','Pizza',19900),
(2,'Veg Burger','Burgers',9900),
(3,'Chicken Biryani','Indian',22000),
(4,'French Fries','Sides',7900),
(5,'Paneer Wrap','Indian',14900),
(6,'Chocolate Brownie','Desserts',8900)
ON DUPLICATE KEY UPDATE food_name=VALUES(food_name), category=VALUES(category), price_paise=VALUES(price_paise);
